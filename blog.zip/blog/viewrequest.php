<?php
include("includes/autoload.php");
include("check.php");
$_dbop=new db_operation;
if(isset($_POST['userID']))
{

$sql="SELECT * FROM `friends` WHERE `friendID`='$_SESSION[user]' AND `status`='pending'";
$friends=$_dbop->getAllQuery($sql);
$where=array('friendID'=>$_dbop->filter($_SESSION['user']),'status'=>'pending');
$numrow=$_dbop->num_rows("friends",$where);
if($numrow)
{
	$text="";
	foreach ($friends as $frnd) {

		$get="SELECT `name` FROM `users` WHERE `userID`='$frnd[userID]'";
		$name=$_dbop->getOneQuery($get);
		$func=$frnd['fID'];
		$fun="onClick='reqFunction(".$func.")'";
		$text.="<h3>".$name['name']."</h3> <button id='a".$frnd['fID']."'".$fun.">Accept</button><hr>" ;

	}

	echo $text;

}
else
{
	$text="
	<div class='center' style='padding:10px'><h3>No Requests..!</h3></div>";
	echo $text;
}

}
?>