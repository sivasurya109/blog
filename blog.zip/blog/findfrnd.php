<?php
include("includes/autoload.php");
include("check.php");
$_dbop=new db_operation;
if(isset($_POST['value']))
{
	$name=$_POST['value']."%";
	$sql="SELECT * FROM `users` WHERE `name` LIKE '$name' AND `userID`!='$_SESSION[user]'";
	$msg = $_dbop->getAllQuery($sql);
	$text="";
	foreach ($msg as $value){
		/*$query="SELECT * FROM `friends` WHERE `friendID`='$value['userID']'";*/
		$where=array('friendID'=> $_dbop->filter($value['userID']),'userID'=>$_dbop->filter($_SESSION['user']));
		$get=$_dbop->select('friends',$where);
		if($get['status']=="friends")
		{
			$text.="<h3>".$value['name']."</h3> <button disabled='true'>Friends</button><hr>";
		}
		else if($get['status']=="pending")
		{
			$text.="<h3>".$value['name']."</h3> <button disabled='true'>Request Sent</button><hr>";
		}
		else
		{
			$text.="<h3>".$value['name']."</h3> <button id='".$value['userID']."' onClick='myFunction(".$value['userID'].")'>add</button><hr>";
		}	
		
	}
	echo $text;
}
?>

