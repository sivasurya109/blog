<?php
include("includes/autoload.php");
include("check.php");
$_dbop=new db_operation;
if(isset($_POST['fID']))
{
	$set=array('status'=>'friends');
	$where=array('fID'=>$_dbop->filter($_POST['fID']));
	$select=$_dbop->select("friends",$where);
	$where1=array('userID'=>$_dbop->filter($select['friendID']),
					'friendID'=>$_dbop->filter($select['userID']),
					'status'=>'friends');
	if($_dbop->insert("friends",$where1))
	{
		$update=$_dbop->update("friends",$set,$where);
		if($update)
		{
		echo "1";
		}
		else
		{

		}

	}
	else
	{

	}
}
?>