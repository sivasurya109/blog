<?php
	session_start();
	$_SESSION['from'] = 1;
	$_SESSION['to']   = 2;
	include_once('includes/autoload.php');
	$_dbop = new DB_operation;
	$msgs = $_dbop->getAllQuery("SELECT `msgID`,`from`,`message` FROM `message` WHERE ( `from`={$_SESSION['from']} and `to`={$_SESSION['to']} ) OR ( `from`={$_SESSION['to']} and `to`={$_SESSION['from']} ) ORDER BY `msgID` DESC LIMIT 15;");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<div class="messanger-box">
		<div class="msg-outer-box">
			<div class="msg-trans-box">
				<div class="msg-inner-box">
					<?php
						$msgs = array_reverse($msgs);
						$output = "";
						foreach ($msgs as $msg) {
							extract($msg);
							$userFlg = ( $_SESSION['from'] == $from )? "from" : "to";
							$output .= " <div class='msg' data-id='$msgID'>";
								if($userFlg == 'to')
										$output .= "<img class='profImg' src='images/$_SESSION[to].jpg' />";
								$output .= " <div class='{$userFlg}'>";
									$output .= " <span>{$message}</span>";
								$output .= "</div>";
								$output .= "<div class='clear'></div>";
							$output .= "</div>";
						}
						echo $output;
					?>
				</div>
			</div>
		</div>
		<div class="msg-controls-box">
			<input type="text" id="msgInput"/>
			<input type="button" id="sendBtn" value="Submit" />
			<input type="hidden" id="fromUserID" value='<?php echo $_SESSION["from"] ?>' />
			<input type="hidden" id="toUserID" value='<?php echo $_SESSION["to"] ?>' />
		</div>
	</div>
	
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
	<script type="text/javascript" src="js/app.js"></script>
</body>
</html>

