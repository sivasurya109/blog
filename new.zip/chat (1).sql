-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2018 at 03:17 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chat`
--

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `fID` int(11) NOT NULL,
  `userID` int(10) NOT NULL,
  `friendID` int(10) NOT NULL,
  `status` enum('friends','pending','rejected') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`fID`, `userID`, `friendID`, `status`) VALUES
(1, 4, 1, 'friends'),
(2, 1, 4, 'friends');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `msgID` int(11) NOT NULL,
  `from` int(11) NOT NULL,
  `to` int(11) NOT NULL,
  `message` text CHARACTER SET utf8 NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('sent','seen') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`msgID`, `from`, `to`, `message`, `time`, `status`) VALUES
(1, 1, 2, 'hi', '2018-07-03 07:34:26', 'seen'),
(2, 2, 1, 'hi da', '2018-07-03 07:34:35', 'seen'),
(3, 1, 2, 'hai', '2018-07-03 16:07:23', 'seen'),
(4, 2, 1, 'fine', '2018-07-03 16:07:46', 'seen'),
(5, 1, 2, 'hi', '2018-07-03 16:12:24', 'seen'),
(6, 2, 1, 'hi da', '2018-07-03 16:14:14', 'seen'),
(7, 1, 2, 'po da dei', '2018-07-03 16:14:25', 'seen'),
(8, 2, 1, 'gukvbukj', '2018-07-03 16:15:17', 'seen'),
(9, 1, 2, 'welcome', '2018-07-03 16:15:45', 'seen'),
(10, 2, 1, 'thank you', '2018-07-03 16:16:02', 'seen'),
(11, 1, 2, 'gjgjhffh', '2018-07-03 16:16:10', 'seen'),
(12, 1, 2, '', '2018-07-03 16:16:11', 'seen'),
(13, 2, 1, 'giugbi', '2018-07-03 16:16:19', 'seen'),
(14, 1, 2, 'a', '2018-07-03 16:17:50', 'seen'),
(15, 1, 2, '', '2018-07-03 16:17:50', 'seen'),
(16, 1, 2, '', '2018-07-03 16:17:50', 'seen'),
(17, 1, 2, '', '2018-07-03 16:17:51', 'seen'),
(18, 1, 2, '', '2018-07-03 16:17:51', 'seen'),
(19, 1, 2, '', '2018-07-03 16:17:51', 'seen'),
(20, 1, 2, '', '2018-07-03 16:17:51', 'seen'),
(21, 1, 2, '', '2018-07-03 16:17:51', 'seen'),
(22, 1, 2, '', '2018-07-03 16:17:52', 'seen'),
(23, 1, 2, '', '2018-07-03 16:17:52', 'seen'),
(24, 1, 2, '', '2018-07-03 16:17:52', 'seen'),
(25, 1, 2, '', '2018-07-03 16:17:52', 'seen'),
(26, 1, 2, '', '2018-07-03 16:17:52', 'seen'),
(27, 1, 2, '', '2018-07-03 16:17:53', 'seen'),
(28, 1, 2, '', '2018-07-03 16:17:53', 'seen'),
(29, 1, 2, '', '2018-07-03 16:17:53', 'seen'),
(30, 1, 2, '', '2018-07-03 16:17:53', 'seen'),
(31, 1, 2, '', '2018-07-03 16:17:54', 'seen'),
(32, 1, 2, '', '2018-07-03 16:17:54', 'seen'),
(33, 1, 2, '', '2018-07-03 16:17:54', 'seen'),
(34, 1, 2, '', '2018-07-03 16:17:54', 'seen'),
(35, 1, 2, '', '2018-07-03 16:17:55', 'seen'),
(36, 1, 2, '', '2018-07-03 16:17:55', 'seen'),
(37, 1, 2, '', '2018-07-03 16:17:55', 'seen'),
(38, 1, 2, '', '2018-07-03 16:17:55', 'seen'),
(39, 1, 2, '', '2018-07-03 16:17:55', 'seen'),
(40, 1, 2, '', '2018-07-03 16:17:56', 'seen'),
(41, 1, 2, '', '2018-07-03 16:17:56', 'seen'),
(42, 1, 2, '', '2018-07-03 16:17:56', 'seen'),
(43, 1, 2, '', '2018-07-03 16:17:56', 'seen'),
(44, 4, 1, 'hi', '2018-07-03 20:48:26', 'seen'),
(45, 1, 4, 'hi da', '2018-07-03 20:48:35', 'seen');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(64) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `name`, `email`, `password`, `time`) VALUES
(1, 'siva', 'siva@gmail.com', 'aaaaaa1@A', '2018-07-02 15:26:54'),
(2, 'surya', 'sivasurya109@gmail.com', 'aaaaaa1@A', '2018-07-02 15:27:48'),
(3, 'vijay', 'vijay@gmail.com', 'aaaaaa1@A', '2018-07-03 07:36:20'),
(4, 'Satheesh', 'satheeshvasan007@gmail.com', 'Ku123456$$', '2018-07-03 16:24:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`fID`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`msgID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `fID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `msgID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
