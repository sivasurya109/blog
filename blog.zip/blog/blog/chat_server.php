<?php 
	session_start();
	if( isset( $_POST['message'] ) ){

		$from = $_SESSION['user'];
		$to   = $_SESSION['touser'];

		 

	}