function myFunction(id) {
		var userID=$("#userId").val();
		var str="#";
		var friendID=id.toString();
		var friendID=str.concat(friendID);		
		$.ajax({
			type:"post",
			url:"sendrequest.php",
			data:"userID="+userID+"&friendID="+id,
			success:function(data)
			{
				if(data)
				{
					alert("Friend Request Sent..!");
					 $(friendID).prop('disabled', true);
					 $(friendID).html('Request Sent');
				}
				else
				{
					alert("not");
				}

			}
		});	
	}
	function reqFunction(id){

		
		var fID=id.toString();		
		$.ajax({
			type:"post",
			url:"acceptrequest.php",
			data:"fID="+fID,
			success:function(data)
			{
				if(data=="1")
				{
					var userID=$("#userId").val();
					$.ajax({
					type:"post",
					url:"viewrequest.php",
					data:"userID="+userID,
					success:function(data)
					{
						$("#content").html('');					
						$('#content').append(data);

					}
				
				});
					
			}
		}
	});
}
$(document).ready(function(){
		/*$(window).load(function(){
		$('.loader').fadeOut();
		});*/
		var userID=$("#userId").val();			
		$('.box-center').css('height',window.innerHeight+"px");
		$('#nav-left').click(function(){
			$("#nav-center").removeClass("active");
			$("#nav-right").removeClass("active");
			$(this).addClass("active");
			var content;
			content='<input type="text" name="find" placeholder="Enter Name To Find" id="findfrnd" class="form-control" /><div class="show-friends" id="show-friends"></div>';
			$("#content").html('');
			$("#content").append(content);
		});
		$('#nav-center').click(function(){
			$("#nav-left").removeClass("active");
			$("#nav-right").removeClass("active");
			$(this).addClass("active");
			$("#content").html('');			
			$.ajax({
				type:'post',
				url:'friendlist.php',
				data:"userID="+userID,
				success:function(data)
				{
					$('#content').append(data);
				}
			});			
		});
		$('#nav-right').click(function(){
			$("#nav-left").removeClass("active");
			$("#nav-center").removeClass("active");
			$(this).addClass("active");
			$("#content").html('');
				
				$.ajax({
				type:"post",
				url:"viewrequest.php",
				data:"userID="+userID,
				success:function(data)
				{
										
					$('#content').append(data);

				}
			});
		});
		
		$('#content').on('keyup','#findfrnd', function(){

			var value=$('#findfrnd').val();
			if(value.length!=0)
			{
				$.ajax({
					type:"post",
					url:"findfrnd.php",
					data:"value="+value,
					success:function(data)
					{ 
						$('#show-friends').html('');
						$('#show-friends').append(data);
					}
				});
			}
			else
			{
				$('#show-friends').html('');
			}
			
		});
	
	});