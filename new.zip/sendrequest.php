<?php
include("includes/autoload.php");
$_dbop=new db_operation;
if(isset($_POST['userID']))
{
	$where=array(
		'userID' => $_dbop->filter($_POST['userID']),
		'friendID'=>$_dbop->filter($_POST['friendID']),
		'status'=>'pending'
	 );	
	$msg = $_dbop->insert("friends",$where);
	if($msg)
	{
		echo "1";

	}
	else{
		
	}
}
?>

