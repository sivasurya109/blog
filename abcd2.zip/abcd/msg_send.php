<?php
	session_start();
	include("includes/autoload.php");
	$_dbop=new db_operation;
	$from = $_SESSION['from'];
	$to = $_SESSION['to'];
	$msg = $_POST['msg'];
	$_dbop->query( " INSERT INTO `message` (`from`,`to`,`message`,`status`) VALUES ('{$from}','{$to}','{$msg}','sent') " );

	echo $_dbop->getOneQuery(" SELECT `msgID` FROM `massage` WHERE `from`={$from} AND `to`={$to} AND `msg`={$msg} ORDER BY `msgID` DESC LIMIT 1 ")['msgID'];