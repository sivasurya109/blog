<?php
include("includes/autoload.php");
$_dbop=new db_operation;
if(isset($_POST['msg']))
{
	

	$_fields = array(
		'msgFrom'=>$_dbop->filter($_POST['from']),
		'msgTo'=>$_dbop->filter($_POST['to']),
		'message' =>$_dbop->filter($_POST['msg'])				
	);	
	$insert=$_dbop->insert("message",$_fields);
	if($insert)
	{
		echo "1";
	}
	
	
	
}else{
	
}
?>