<?php include('check.php');
include("includes/autoload.php");
$_dbop=new db_operation;

?>

<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/style1.css">
	<style type="text/css">
		.container{
			width:96%;margin-left:2%;margin-right:2%;min-height:600px;
		}
		input{
			border:1px solid red;
		}
		.box-center {
		      /*  box-shadow: 20px 10px 10px -15px #afa7a7; */
		}
	</style>
</head>
<body>
	<div class="container" style="">
		<div class="row">				
			<div class="box-center" style="border:1.5px solid #eee">
				<div class="nav" style="border-bottom:1.5px solid #eee;height:12%;margin-bottom:10px ">
					<div class="nav-head">

						<div>
							<?php
							$get="SELECT `name` FROM `users` WHERE `userID`='$_SESSION[user]'";
							$name=$_dbop->getOneQuery($get);
							echo "<h3 style='text-align:center;'>$name[name]</h3>";
							?>
						</div>
						
					</div>
					<div class="row nav-content">
						<div class="nav-left">
							<button class="btn-nav" id="nav-left">Search/Add</button> 			
						</div>
						<div class="nav-center">
							<button class="btn-nav" id="nav-center">Friends List</button> 
						</div>
						<div class="nav-right">
							<button class="btn-nav" id="nav-right">Requests</button> 
						</div>
					</div>
				</div>
				<input type="hidden" id="userId" value="<?php echo $_SESSION['user']?>">		
				<div class="content" id="content">	
					<?php
					$userID=$_SESSION['user'];
					$sql="SELECT DISTINCT `friendID` FROM `friends` WHERE `userID`='$userID' AND `status`='friends'";
					$msg = $_dbop->getAllQuery($sql);
					$text="";
					foreach ($msg as $value) {	
					$get="SELECT `name` FROM `users` WHERE `userID`='$value[friendID]'";
					$name=$_dbop->getOneQuery($get);
					$text.="<div style='padding:10px'><h3>".$name['name']."</h3><a class='btn' style='text-decoration:none' href='chat1.php?id=".$value['friendID']."'>Chat</a></div>" ;
					}
					echo $text;
					
					?>	
					
				</div>	
					
				</div>		
			</div>				
		</div>		
	</div>
</body>
<script type="text/javascript" src="scripts/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="scripts/newscript.js"></script>
</html>
