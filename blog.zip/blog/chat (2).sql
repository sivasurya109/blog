-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 07, 2018 at 01:20 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chat`
--

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `fID` int(11) NOT NULL,
  `userID` int(10) NOT NULL,
  `friendID` int(10) NOT NULL,
  `status` enum('friends','pending','rejected') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`fID`, `userID`, `friendID`, `status`) VALUES
(1, 4, 1, 'friends'),
(2, 1, 4, 'friends'),
(3, 1, 2, 'friends'),
(4, 1, 3, 'pending'),
(5, 2, 1, 'friends');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `msgID` int(11) NOT NULL,
  `from` int(11) NOT NULL,
  `to` int(11) NOT NULL,
  `message` text CHARACTER SET utf8 NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('sent','seen') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`msgID`, `from`, `to`, `message`, `time`, `status`) VALUES
(1, 1, 2, 'hi', '2018-07-03 07:34:26', 'seen'),
(2, 2, 1, 'hi da', '2018-07-03 07:34:35', 'seen'),
(3, 1, 2, 'hai', '2018-07-03 16:07:23', 'seen'),
(4, 2, 1, 'fine', '2018-07-03 16:07:46', 'seen'),
(5, 1, 2, 'hi', '2018-07-03 16:12:24', 'seen'),
(6, 2, 1, 'hi da', '2018-07-03 16:14:14', 'seen'),
(7, 1, 2, 'po da dei', '2018-07-03 16:14:25', 'seen'),
(8, 2, 1, 'gukvbukj', '2018-07-03 16:15:17', 'seen'),
(9, 1, 2, 'welcome', '2018-07-03 16:15:45', 'seen'),
(10, 2, 1, 'thank you', '2018-07-03 16:16:02', 'seen'),
(11, 1, 2, 'gjgjhffh', '2018-07-03 16:16:10', 'seen'),
(12, 1, 2, '', '2018-07-03 16:16:11', 'seen'),
(13, 2, 1, 'giugbi', '2018-07-03 16:16:19', 'seen'),
(14, 1, 2, 'a', '2018-07-03 16:17:50', 'seen'),
(15, 1, 2, '', '2018-07-03 16:17:50', 'seen'),
(16, 1, 2, '', '2018-07-03 16:17:50', 'seen'),
(17, 1, 2, '', '2018-07-03 16:17:51', 'seen'),
(18, 1, 2, '', '2018-07-03 16:17:51', 'seen'),
(19, 1, 2, '', '2018-07-03 16:17:51', 'seen'),
(20, 1, 2, '', '2018-07-03 16:17:51', 'seen'),
(21, 1, 2, '', '2018-07-03 16:17:51', 'seen'),
(22, 1, 2, '', '2018-07-03 16:17:52', 'seen'),
(23, 1, 2, '', '2018-07-03 16:17:52', 'seen'),
(24, 1, 2, '', '2018-07-03 16:17:52', 'seen'),
(25, 1, 2, '', '2018-07-03 16:17:52', 'seen'),
(26, 1, 2, '', '2018-07-03 16:17:52', 'seen'),
(27, 1, 2, '', '2018-07-03 16:17:53', 'seen'),
(28, 1, 2, '', '2018-07-03 16:17:53', 'seen'),
(29, 1, 2, '', '2018-07-03 16:17:53', 'seen'),
(30, 1, 2, '', '2018-07-03 16:17:53', 'seen'),
(31, 1, 2, '', '2018-07-03 16:17:54', 'seen'),
(32, 1, 2, '', '2018-07-03 16:17:54', 'seen'),
(33, 1, 2, '', '2018-07-03 16:17:54', 'seen'),
(34, 1, 2, '', '2018-07-03 16:17:54', 'seen'),
(35, 1, 2, '', '2018-07-03 16:17:55', 'seen'),
(36, 1, 2, '', '2018-07-03 16:17:55', 'seen'),
(37, 1, 2, '', '2018-07-03 16:17:55', 'seen'),
(38, 1, 2, '', '2018-07-03 16:17:55', 'seen'),
(39, 1, 2, '', '2018-07-03 16:17:55', 'seen'),
(40, 1, 2, '', '2018-07-03 16:17:56', 'seen'),
(41, 1, 2, '', '2018-07-03 16:17:56', 'seen'),
(42, 1, 2, '', '2018-07-03 16:17:56', 'seen'),
(43, 1, 2, '', '2018-07-03 16:17:56', 'seen'),
(44, 4, 1, 'hi', '2018-07-03 20:48:26', 'seen'),
(45, 1, 4, 'hi da', '2018-07-03 20:48:35', 'seen'),
(46, 1, 4, 'hi', '2018-07-06 16:56:16', 'sent'),
(47, 1, 4, '', '2018-07-06 16:56:17', 'sent'),
(48, 1, 4, '', '2018-07-06 16:56:18', 'sent'),
(49, 1, 4, '', '2018-07-06 16:56:19', 'sent'),
(50, 1, 4, '', '2018-07-06 16:56:19', 'sent'),
(51, 1, 4, '', '2018-07-06 16:56:20', 'sent'),
(52, 1, 4, '', '2018-07-06 16:56:20', 'sent'),
(53, 1, 4, '', '2018-07-06 16:56:20', 'sent'),
(54, 1, 4, '', '2018-07-06 17:06:11', 'sent'),
(55, 1, 4, '', '2018-07-06 17:06:15', 'sent'),
(56, 1, 4, '', '2018-07-06 17:06:15', 'sent'),
(57, 1, 4, '', '2018-07-06 17:06:15', 'sent'),
(58, 1, 4, '', '2018-07-06 17:06:15', 'sent'),
(59, 1, 4, '', '2018-07-06 17:06:16', 'sent'),
(60, 1, 4, '', '2018-07-06 17:06:16', 'sent'),
(61, 1, 4, '', '2018-07-06 17:06:16', 'sent'),
(62, 1, 4, '', '2018-07-06 17:06:16', 'sent'),
(63, 1, 4, '', '2018-07-06 17:06:16', 'sent'),
(64, 1, 4, '', '2018-07-06 17:06:17', 'sent'),
(65, 1, 4, '', '2018-07-06 17:06:17', 'sent'),
(66, 1, 4, '', '2018-07-06 17:06:17', 'sent'),
(67, 1, 4, '', '2018-07-06 17:06:17', 'sent'),
(68, 1, 4, '', '2018-07-06 17:06:18', 'sent'),
(69, 1, 4, '', '2018-07-06 17:06:18', 'sent'),
(70, 1, 4, '', '2018-07-06 17:09:12', 'sent'),
(71, 1, 4, '', '2018-07-06 17:09:12', 'sent'),
(72, 1, 4, '', '2018-07-06 17:09:12', 'sent'),
(73, 1, 4, '', '2018-07-06 17:09:12', 'sent'),
(74, 1, 4, '', '2018-07-06 17:09:13', 'sent'),
(75, 1, 4, '', '2018-07-06 17:09:13', 'sent'),
(76, 1, 4, '', '2018-07-06 17:09:13', 'sent'),
(77, 1, 4, '', '2018-07-06 17:09:13', 'sent'),
(78, 1, 4, '', '2018-07-06 17:09:13', 'sent'),
(79, 1, 4, '', '2018-07-06 17:09:14', 'sent'),
(80, 1, 4, '', '2018-07-06 17:09:14', 'sent'),
(81, 1, 4, '', '2018-07-06 17:09:14', 'sent'),
(82, 1, 4, '', '2018-07-06 17:09:14', 'sent'),
(83, 1, 4, '', '2018-07-06 17:09:14', 'sent'),
(84, 1, 4, '', '2018-07-06 17:09:14', 'sent'),
(85, 1, 4, '', '2018-07-06 17:09:15', 'sent'),
(86, 1, 4, '', '2018-07-06 17:09:15', 'sent'),
(87, 1, 4, '', '2018-07-06 17:09:15', 'sent'),
(88, 1, 4, '', '2018-07-06 17:09:15', 'sent'),
(89, 1, 4, '', '2018-07-06 17:09:49', 'sent'),
(90, 1, 4, '', '2018-07-06 17:09:50', 'sent'),
(91, 1, 4, '', '2018-07-06 17:09:50', 'sent'),
(92, 1, 4, '', '2018-07-06 17:09:51', 'sent'),
(93, 1, 4, '', '2018-07-06 17:09:51', 'sent'),
(94, 1, 3, '', '2018-07-06 17:10:02', 'sent'),
(95, 1, 3, '', '2018-07-06 17:10:03', 'sent'),
(96, 1, 3, '', '2018-07-06 17:10:03', 'sent'),
(97, 1, 3, '', '2018-07-06 17:10:03', 'sent'),
(98, 1, 3, '', '2018-07-06 17:10:04', 'sent'),
(99, 1, 3, '', '2018-07-06 17:10:04', 'sent'),
(100, 1, 4, '', '2018-07-06 17:11:38', 'sent'),
(101, 1, 4, '', '2018-07-06 17:11:39', 'sent'),
(102, 1, 4, '', '2018-07-06 17:11:39', 'sent'),
(103, 1, 4, '', '2018-07-06 17:11:39', 'sent'),
(104, 1, 4, '', '2018-07-06 17:11:39', 'sent'),
(105, 1, 4, '', '2018-07-06 17:11:39', 'sent'),
(106, 1, 4, '', '2018-07-06 17:11:40', 'sent'),
(107, 1, 4, '', '2018-07-06 17:11:40', 'sent'),
(108, 1, 4, '', '2018-07-06 17:11:40', 'sent'),
(109, 1, 4, '', '2018-07-06 17:11:40', 'sent'),
(110, 1, 4, '', '2018-07-06 17:11:50', 'sent'),
(111, 1, 4, '', '2018-07-06 17:12:01', 'sent'),
(112, 1, 4, '', '2018-07-06 17:13:28', 'sent'),
(113, 1, 4, '', '2018-07-06 17:13:28', 'sent'),
(114, 1, 4, '', '2018-07-06 17:13:29', 'sent'),
(115, 1, 4, '', '2018-07-06 17:13:29', 'sent'),
(116, 1, 4, '', '2018-07-06 17:13:30', 'sent'),
(117, 1, 4, '', '2018-07-06 17:13:30', 'sent'),
(118, 1, 4, '', '2018-07-06 17:13:30', 'sent'),
(119, 1, 4, '', '2018-07-06 17:13:30', 'sent'),
(120, 1, 4, '', '2018-07-06 17:13:31', 'sent'),
(121, 1, 4, '', '2018-07-06 17:13:31', 'sent'),
(122, 1, 4, '', '2018-07-06 17:13:31', 'sent'),
(123, 1, 4, '', '2018-07-06 17:13:31', 'sent'),
(124, 1, 4, '', '2018-07-06 17:13:31', 'sent'),
(125, 1, 4, '', '2018-07-06 17:13:32', 'sent');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(64) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `name`, `email`, `password`, `time`) VALUES
(1, 'siva', 'siva@gmail.com', 'aaaaaa1@A', '2018-07-02 15:26:54'),
(2, 'surya', 'sivasurya109@gmail.com', 'aaaaaa1@A', '2018-07-02 15:27:48'),
(3, 'vijay', 'vijay@gmail.com', 'aaaaaa1@A', '2018-07-03 07:36:20'),
(4, 'Satheesh', 'satheeshvasan007@gmail.com', 'Ku123456$$', '2018-07-03 16:24:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`fID`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`msgID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `fID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `msgID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
