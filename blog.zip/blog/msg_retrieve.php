<?php
	session_start();
	include("includes/autoload.php");
	$_dbop=new db_operation;
	$from = $_SESSION['from'];
	$to = $_SESSION['to'];

	if( isset($_POST['lastMsgID']) ){

	$lastMsgID = $_POST['lastMsgID'];
	
	$msg = $_dbop->getAllQuery("SELECT `msgID`,`from`,`message`,`time` FROM `message` WHERE ( ( `from`={$from} AND `to`={$to} ) OR ( `from`={$to} AND `to`={$from} ) ) AND ( `msgID` < {$lastMsgID} ) ORDER BY `msgID` DESC LIMIT 15");

	echo (is_null($msg) OR !is_array($msg) )?'':json_encode($msg);

	}else{
		echo "";
	}

	// echo $msg;