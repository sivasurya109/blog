<?php
	session_start();
	include("includes/autoload.php");
	$_dbop=new db_operation;
	$from = $_SESSION['from'];
	$to = $_SESSION['to'];
	$msg = $_dbop->getOneQuery("SELECT `msgID`,`from`,`message`,`time` FROM `message` WHERE `from`='{$to}' AND `status`='sent' ORDER BY `msgID` DESC LIMIT 1");
	$_dbop->update('message', [
			'status' => 'seen'
		], [
			'msgID' => $msg['msgID']
		]);
	echo (is_null($msg))?'':json_encode($msg);