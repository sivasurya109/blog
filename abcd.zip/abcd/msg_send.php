<?php
	session_start();
	include("includes/autoload.php");
	$_dbop=new db_operation;
	$from = $_SESSION['from'];
	$to = $_SESSION['to'];
	$msg = $_POST['msg'];
	echo $_dbop->query( " INSERT INTO `message` (`from`,`to`,`message`,`status`) VALUES ('{$from}','{$to}','{$msg}','sent') " );