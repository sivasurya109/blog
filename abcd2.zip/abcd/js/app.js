var flgs = {
	lastMsgID : $('.msg:first-child').data('id'),
	msgComplete : false,
};

var users = {
	from : $('#fromUserID').val(),
	to : $('#toUserID').val(),
};


(function(){
	scrollBottom();
	$(window).on('resize load', heightUpdate);
	$('#sendBtn').on('click', sendReq);
	$('.msg-inner-box').on('scroll', function(){
		if( $(this).scrollTop() === 0 ){
			msgRetrieve();
		}
	});

})();

function heightUpdate(){
	const windowHeight = window.innerHeight;
	const chatCtrlHeight = $('.msg-controls-box').innerHeight();
	$('.messanger-box').css('height', (windowHeight - 20) +"px");
	$('.msg-trans-box').css('height', (windowHeight - chatCtrlHeight)+"px");
}

function sendReq(){
	var msg = $('#msgInput').val();
	$.ajax({
		url : "msg_send.php",
		data : { msg },
		type : 'post',
		success : function(data){
			$('.msg-inner-box').append(`
					<div class="msg">
						<div class="from">
							<span>${msg}</span>
						</div>
						<div class="clear"></div>
					</div>
				`);
			clearInput();
			scrollBottom();
		}
	});
}

function scrollPrev(val){
	$('.msg-inner-box').first().stop().delay(500).animate({
		scrollTop: ($('[data-id='+val+']').first().offset().top)
	},500);
}

function receiveMsg(){
	$.get('msg_recieve.php', function(data){
		if(data !== ''){
			msg = JSON.parse(data);
			$('.msg-inner-box').append(`
						<div class="msg">
							<img class='profImg' src='images/${msg.from}.jpg' />
							<div class="to">
								<span>${msg.message}</span>
							</div>
							<div class="clear"></div>
						</div>
					`);
			scrollBottom();
		}
	});
}
setInterval(receiveMsg, 2000);

function msgRetrieve(){
	if( !flgs.msgComplete ){
		$.ajax({
			url : "msg_retrieve.php",
			data : { lastMsgID : flgs.lastMsgID },
			type : 'post',
			success : function(data){

				if( data !== "" && data !== "[]" ){
					var output = "";
					const msgs = JSON.parse(data).reverse();
					let userFlg = "";
					msgs.forEach(function(msg){
						userFlg = ( users.from === msg.from )? "from" : "to";
						output += `<div class='msg' data-id='${msg.msgID}'>`;
							if( msg.from === users.to ){
								output += `<img class='profImg' src='images/${msg.from}.jpg' />`;
							}
							output += `<div class='${userFlg}'>`;
								output += `<span>${msg.message}</span>`;
							output += `</div><div class='clear'></div>`;
						output += `</div>`;
					});
					output += `<div id='divider${flgs.lastMsgID}'>`;
					$('.msg-inner-box').prepend(output);
					scrollPrev(flgs.lastMsgID);
					flgs.lastMsgID = $('.msg:first-child').data('id');
					console.log(flgs.lastMsgID);
				}else if( data === "[]" ){
					flgs.msgComplete = true;
				}
			}
		});
	}
}

function scrollBottom(){
	$(".msg-inner-box").animate({scrollTop: $(".msg-inner-box")[0].scrollHeight }, 1000);
}

function clearInput(){
	$("#msgInput").val('').trigger('focus');
}

