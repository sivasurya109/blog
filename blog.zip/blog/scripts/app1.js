// var innerHeight = window.innerHeight;

(function(){
	
	$(window).on('resize load', function(){
		$('.box-left, .box-center, .box-right').css('height',window.innerHeight+"px"  );
		
		$msgInputHeight = 50;
		$windowHeight = $(window).innerHeight();

		$msgBoxHeight = ( $windowHeight - $msgInputHeight ) + "px";
		$('.msg-trans-box').css('height', $msgBoxHeight);
	});

$("#userTo").click(function() {	
var value=$('#userID').val();				
$('#toTO').val(value);
});		


$(document).ready(function(){

			
});


$("#msgSend").click(function() {
		var msgElem = $("#msgInput");
    	var msg =  msgElem.html(); 
    	var from=$('#from').val();
    	var to=$('#toTO').val();     		
    	/*var msg='<div class="msg"><div class="from"><span>'+msg+'</span></div><div class="clear"></div></div>';    */
        $.ajax({
        	type:"post",
			url:"msgsend.php",
			data:"msg="+msg+"&from="+from+"&to="+to,
			success:function(data){                           
				if(data)
				{
					
					$('.msg-box').append('<div class="msg"><div class="from"><span>'+msg+'</span></div><div class="clear"></div></div>');
			        $("#msgInput").html('').trigger('focus');
			        $(".msg-box").stop().animate({ scrollTop: $(".msg-box")[0].scrollHeight}, 1000);
					
				}				
				else
				{
					alert("something wrong");
				}
			} 
        });
        
});



})();
