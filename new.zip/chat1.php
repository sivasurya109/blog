<?php
include("check.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Chat Page</title>
	
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/style1.css">
	
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="box-left">	
				<div class="friend-list-box">
					<select name="user" id="userID" required="">
						<option>SELECT ONE</option>
					
					<?php
						include("includes/autoload.php");
						$_dbop=new db_operation;
						$data=$_dbop->select_all("users");
						$i=1;
						foreach ($data as $dat) {
							?>
							<option value="<?php echo $dat['userID']?>"><?php echo $dat['email']?></option>
							
							<?php
						}
					?>
					</select>	
					<br>
					<button class="btn" id="userTo">Click</button>				
				</div>			
			</div> 
			<div class="box-center ball">
				<div class="chat-box ba w-100">
					<div class="chat-box-heading">
						<div id="toId"></div>
						<input type="hidden" name="to" id="to" value="">
					</div>
					<div class="msg-trans-box" >	
						<div class="msg-box chat-background">		
							<div class="msg">
								<div class="from">
									<span class="text">
										Hi
									</span>
								</div>
								<div class="clear"></div>
							</div>

							<div class="msg">
								<div class="to">
									<span class="text">Hi</span>
								</div>
							</div>
						</div>
					</div>
					<input type="hidden" name="from" id="from" value="<?php echo $_SESSION['user'];?>">
					<input type="hidden" name="to" id="toTO" value="">
					<div class="msg-input" style="">
						<div class="chat-footer">
							<div class="chat-input" id="msgInput"  contenteditable="true"></div>
						</div>
						<div class="chat-submit">
						<button class="btn btn-custom btn-chat" type="button" id="msgSend">Send</button>
						</div>

					</div>

				</div>
			</div>
			<!-- <div class="box-right">
				
			</div> -->
			<div class="clear"></div>
		</div>

	</div>
	<script type="text/javascript" src="scripts/jquery-2.1.4.min.js"></script>	
	<script type="text/javascript" src="scripts/app1.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){

			
		});
				
	</script>
</body>
</html>