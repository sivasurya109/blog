(function(){
	$('#sendBtn').on('click', function(){
		var msg = $('#msgInput').val();
		// alert(msg);
		$.ajax({
			url : "msg_send.php",
			data : { msg },
			type : 'post',
			success : function(data){
				$('.messanger-div').append(msg+"<br>");
			}
		});
	});
})();

function receiveMsg(){
	$.get('msg_recieve.php', function(data){
		if(data !== '')
			$('.messanger-div').append(data+"<br>");
	});
}

setInterval(receiveMsg, 2000);

