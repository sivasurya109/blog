<?php
session_start();
include("includes/autoload.php");

// var_dump($_SESSION['user']);

// $_dbop=new db_operation;
// $_fields = array(
// 'email' => 	$_dbop->filter("siva_surya123@gmail.com"),
// 'password' 	=> 	$_dbop->filter("siva123")				
// );
/*

$_where=array('userID'=>'6');

$select=$_dbop->delete("users",$_where);
if($select)
{
	echo "success";
}
else
{
	echo "not";
}*/
?>
