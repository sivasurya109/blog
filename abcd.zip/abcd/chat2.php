<?php
	session_start();
	$_SESSION['from'] = 2;
	$_SESSION['to']   = 1;
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- <link rel="stylesheet" type="text/css" href=""> -->
</head>
<body>
	<div class="messanger-div">
	</div>
	<input type="text" id="msgInput"/>
	<input type="button" id="sendBtn" value="Submit" />
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
	<script type="text/javascript" src="js/app.js"></script>
</body>
</html>

