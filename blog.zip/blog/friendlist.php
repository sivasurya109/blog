<?php 
include("includes/autoload.php");
$_dbop=new db_operation;
if(isset($_POST['userID']))
{
$userID=$_POST['userID'];
$sql="SELECT DISTINCT `friendID` FROM `friends` WHERE `userID`='$userID' AND `status`='friends'";
$msg = $_dbop->getAllQuery($sql);
$text="";
foreach ($msg as $value) {	
$get="SELECT `name` FROM `users` WHERE `userID`='$value[friendID]'";
$name=$_dbop->getOneQuery($get);
$text.="<div style='padding:10px'><h3>".$name['name']."</h3><a class='btn' style='text-decoration:none' href='chat1.php?id=".$value['friendID']."'>Chat</a></div>" ;
}
echo $text;
}

?>			