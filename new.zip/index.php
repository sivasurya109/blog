<?php include('check.php');
include("includes/autoload.php");
$_dbop=new db_operation;

?>

<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/style1.css">
	<style type="text/css">
		.container{
			width:96%;margin-left:2%;margin-right:2%;min-height:600px;
		}
		input{
			border:1px solid red;
		}
	</style>
</head>
<body>

	<div class="container" style="">
		<div clas="nav">

		</div>
		<div class="row">
			<div>
				<?php
					$get="SELECT `name` FROM `users` WHERE `userID`='$_SESSION[user]'";
					$name=$_dbop->getOneQuery($get);
					echo "<h3>Welcome $name[name]</h3><br><hr>";
				?>
			</div>
			
			<div class="box-left"style="">
				<div class="friend-list">
					<h3>Add Friends</h3>
					<input type="text" name="find" id="findfrnd" class="form-control" />
					<input type="hidden" id="userId" value="<?php echo $_SESSION['user']?>">
					<div class="show-friends" id="show-friends">						
					</div>
				</div>			
			</div>	
			<div class="box-center">
				<div class="view-friend">
					<h3>Friends List</h3>
					<?php 
						/*echo $_SESSION['user'];*/
						$sql="SELECT DISTINCT `friendID` FROM `friends` WHERE `userID`='$_SESSION[user]' AND `status`='friends'";
						/*echo $sql;*/
						$msg = $_dbop->getAllQuery($sql);
						$text="";
						
						foreach ($msg as $value) {							

							/*if($check!=$value['friendID'])
							{*/
								$get="SELECT `name` FROM `users` WHERE `userID`='$value[friendID]'";
								$name=$_dbop->getOneQuery($get);
								$text.="<h3>".$name['name']."</h3><a class='btn' style='text-decoration:none' href='chat.php?id=".$value['friendID']."'>Chat</a>" ;
								
							/*}*/							

						}
						echo $text;
						
					?>					
				</div>
			</div>	
			<div class="box-right">
				<div class="view-friend">
					<h3>Friend Request</h3>
					<div class="request-friend" id="request-friend">
						
					</div>					
				</div>
			</div>	
		</div>		
	</div>
</body>
<script type="text/javascript" src="scripts/jquery-2.1.4.min.js"></script>
<script type="text/javascript">	

	function reqFunction(id){

		var userID=$("#userId").val();
		var fID=id.toString();		
		$.ajax({
			type:"post",
			url:"acceptrequest.php",
			data:"fID="+fID,
			success:function(data)
			{
				alert(data);				
				location.reload();
			}
		});
	}
	function myFunction(id) {
		var userID=$("#userId").val();
		var str="#";
		var friendID=id.toString();
		var friendID=str.concat(friendID);		
		$.ajax({
			type:"post",
			url:"sendrequest.php",
			data:"userID="+userID+"&friendID="+id,
			success:function(data)
			{
				if(data)
				{
					alert("Friend Request Sent..!");
					 $(friendID).prop('disabled', true);
					 $(friendID).html('Request Sent');
				}
				else
				{
					alert("not");
				}

			}
		});	
	}
	$(document).ready(function(){

		var userID=$("#userId").val();
		$.ajax({
			type:"post",
			url:"viewrequest.php",
			data:"userID="+userID,
			success:function(data)
			{
				$("#request-friend").html('');
				$("#request-friend").append(data);

			}
		});

		$('#findfrnd').keyup(function(){
			var value=$(this).val();
			if(value.length!=0)
			{
				$.ajax({
					type:"post",
					url:"findfrnd.php",
					data:"value="+value,
					success:function(data)
					{ 
						$('#show-friends').html('');
						$('#show-friends').append(data);
					}
				});
			}
			else
			{
				$('#show-friends').html('');
			}
		});
	});
</script>
</html>
